package app.callisto.com.callisto.viewmodels;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.util.Log;

import java.util.List;
import app.callisto.com.callisto.data.db.PostRoomDBRepository;
import app.callisto.com.callisto.data.remote.WebServiceRepository;
import app.callisto.com.callisto.model.ResultModel;

public class PostsListViewModel extends AndroidViewModel {

    private PostRoomDBRepository postRoomDBRepository;
    private LiveData<List<ResultModel>> mAllPosts;
    WebServiceRepository webServiceRepository ;
    private final LiveData<List<app.callisto.com.callisto.model.ResultModel>> retroObservable;
    public PostsListViewModel(Application application){
        super(application);
        postRoomDBRepository = new PostRoomDBRepository(application);
        webServiceRepository = new WebServiceRepository(application);
        retroObservable = webServiceRepository.providesWebService();
        //postRoomDBRepository.insertPosts(retroObservable.getValue());
        mAllPosts = postRoomDBRepository.getAllPosts();

    }

    public LiveData<List<ResultModel>> getAllPosts() {
        return mAllPosts;
    }

   /* public LiveData<List<ResultModel>> getProjectRetroListObservable() {
        return retroObservable;
    }*/

/*    public void insert(User user) {
        userRepository.insert(user);
    }*/
}
