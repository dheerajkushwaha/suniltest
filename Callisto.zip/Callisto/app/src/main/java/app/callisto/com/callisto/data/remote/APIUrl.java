package app.callisto.com.callisto.data.remote;

public class APIUrl {
    public static final String BASE_URL = "https://jsonplaceholder.typicode.com/";
}
