package app.callisto.com.callisto.data.db;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import java.util.List;
import app.callisto.com.callisto.data.remote.PostInfoDao;
import app.callisto.com.callisto.model.ResultModel;


public class PostRoomDBRepository {
    private PostInfoDao postInfoDao;
    LiveData<List<app.callisto.com.callisto.model.ResultModel>> mAllPosts;

    public PostRoomDBRepository(Application application){
         PostInfoRoomDataBase db = PostInfoRoomDataBase.getDatabase(application);
        postInfoDao = db.postInfoDao();
        mAllPosts = postInfoDao.getAllPosts();
    }

    public LiveData<List<app.callisto.com.callisto.model.ResultModel>> getAllPosts() {
        return mAllPosts;
    }
    public void insertPosts (List<app.callisto.com.callisto.model.ResultModel> resultModel) {
        new insertAsyncTask(postInfoDao).execute(resultModel);
    }

    private static class insertAsyncTask extends AsyncTask<List<ResultModel>, Void, Void> {

        private PostInfoDao mAsyncTaskDao;
        insertAsyncTask(PostInfoDao dao) {
            mAsyncTaskDao = dao;
        }
        @Override
        protected Void doInBackground(final List<app.callisto.com.callisto.model.ResultModel>... params) {
            mAsyncTaskDao.insertPosts(params[0]);
            return null;
        }
    }
}
