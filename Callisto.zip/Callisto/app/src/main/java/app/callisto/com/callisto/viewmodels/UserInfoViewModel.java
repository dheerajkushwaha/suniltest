package app.callisto.com.callisto.viewmodels;

import android.arch.lifecycle.ViewModel;

public class UserInfoViewModel extends ViewModel {
}
