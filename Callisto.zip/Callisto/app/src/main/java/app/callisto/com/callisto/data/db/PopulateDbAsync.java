package app.callisto.com.callisto.data.db;

import android.os.AsyncTask;

import app.callisto.com.callisto.data.remote.PostInfoDao;

public class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

    private final PostInfoDao mDao;

    PopulateDbAsync(PostInfoRoomDataBase db) {
        mDao = db.postInfoDao();
    }

    @Override
    protected Void doInBackground(final Void... params) {
        mDao.deleteAll();
       /* User user = new User("Chandra","SW");
        mDao.insert(user);
        user = new User("Mohan","student");
        mDao.insert(user);*/
        return null;
    }
}
